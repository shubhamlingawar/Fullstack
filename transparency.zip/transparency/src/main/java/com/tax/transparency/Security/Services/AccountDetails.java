package com.tax.transparency.Security.Services;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.tax.transparency.Entity.Account;


public class AccountDetails implements UserDetails {

	private int id;
	
	private String username;
	private String password;
	private String companyCode;
	private Collection<? extends GrantedAuthority> authorities;

	public AccountDetails(int id, String username, String companyCode, String password,
			Collection<? extends GrantedAuthority> authorities) {
		this.id = id;
		this.username = username;
		this.companyCode = companyCode;
		this.password = password;
		this.authorities = authorities;
	}

	public static AccountDetails build(Account account) {
		List<GrantedAuthority> authorities =  Arrays.stream(account.getRoles().split(","))
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

		return new AccountDetails(
				account.getId(), 
				account.getUsername(), 
				account.getCompanyCode(),
				account.getPassword(), 
				authorities);
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public int getId() {
		return id;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		AccountDetails user = (AccountDetails) o;
		return Objects.equals(id, user.id);
	}
}


