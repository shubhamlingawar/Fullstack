package com.tax.transparency.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tax.transparency.Entity.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	Employee findEmpById(int id);

}
