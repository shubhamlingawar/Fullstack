package com.tax.transparency.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Feedback {
		private String name;
		private String email;
		private String PaymentType;
		private long salary;
		private long inhandSalary;
		private long tax;

	}

   
