package com.tax.transparency.Entity;

public class EmployeeSalary {

}
