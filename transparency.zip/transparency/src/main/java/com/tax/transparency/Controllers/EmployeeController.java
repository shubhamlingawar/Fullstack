package com.tax.transparency.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tax.transparency.Entity.Employee;
import com.tax.transparency.Repository.EmployeeRepository;

@RestController
@RequestMapping("/api/")

public class EmployeeController {
	
	@Autowired
	private EmployeeRepository empRepo;

	@GetMapping("/employee")
	public List<Employee> findAll(){
		return empRepo.findAll();
	}
	
	@GetMapping("/employee/{id}")
	public Employee findById(@PathVariable int id) {
		return empRepo.findEmpById(id);
	}
	
	@PostMapping("/employee/save")
	public Employee save(@RequestBody Employee employee) {
		empRepo.save(employee);	
		return employee;
	}
	
	@PutMapping("/employee/update")
	public Employee update(@RequestBody Employee employee) {
		empRepo.save(employee);
		return employee;
	}
	
	@DeleteMapping("/employee/delete/{id}")
	public void delete(@PathVariable int id)
	{
		empRepo.deleteById(id);
	}
}
