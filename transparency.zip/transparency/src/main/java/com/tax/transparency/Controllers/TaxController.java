package com.tax.transparency.Controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tax.transparency.Entity.Tax;
import com.tax.transparency.Repository.EmployeeRepository;
import com.tax.transparency.Repository.TaxRepository;
import com.tax.transparency.Security.Services.TaxService;
@RestController
@RequestMapping("/api/")

public class TaxController {
	
	@Autowired
	private TaxService taxservice;
	
	@Autowired
	private TaxRepository taxRepo;
	
	@Autowired
	private EmployeeRepository empRepo;
	
	
	@GetMapping("/tax/salary/{salary}")
	public double CalculateTax(@PathVariable long salary) {
		
	double taxdeduction=taxservice.CalculateTax(salary);	
		
		return taxdeduction;
		
	}
	
	@GetMapping("/tax/{id}")
	public Tax FindById(@PathVariable int id)
	{
		return taxRepo.findById(id);
	}
	
	@PostMapping("/tax/{id}/save")
	public Optional<Tax> SaveTax(@PathVariable int id,@RequestBody Tax tax) {
		
	return empRepo.findById(id).map(
			employee -> {
				tax.setEmployee(employee);
				return taxRepo.save(tax);
				
			});
		
	
	
	}

}

