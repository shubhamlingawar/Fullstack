package com.tax.transparency.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tax.transparency.Entity.Tax;

public interface TaxRepository extends JpaRepository<Tax, Integer> {

	Tax findById(int id);
}
