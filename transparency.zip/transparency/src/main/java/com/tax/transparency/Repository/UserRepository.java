package com.tax.transparency.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tax.transparency.Entity.Account;

public interface UserRepository extends JpaRepository<Account, Integer> {

	Optional<Account> findByUsername(String username);

	Boolean existsByUsername(String username);

}
