package com.tax.transparency.Controllers;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tax.transparency.Config.EmailCfg;
import com.tax.transparency.Entity.Feedback;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/")
public class FeedbackController {

	@Autowired
    private JavaMailSender javaMailSender;
	
    private EmailCfg emailCfg;

    public FeedbackController(EmailCfg emailCfg) {
        this.emailCfg = emailCfg;
    }

    
    
    
    @RequestMapping("/sendemail/{name}/{email}/{PaymentType}/{salary}/{inhandSalary}/{tax}")
	public String send(@PathVariable String name,@PathVariable String email,
	  		@PathVariable String PaymentType, @PathVariable long salary, @PathVariable long inhandSalary, @PathVariable long tax) throws AddressException, MessagingException, IOException {

     	Feedback notify = new Feedback(name,email, PaymentType, salary,inhandSalary,tax);
      	

            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo(notify.getEmail());

        
            msg.setSubject("Regarding Tax Deduction");
            
            
            
            msg.setText("Hi   "+ notify.getName()+",\n"+ "You have received Salary  " + notify.getSalary()+",\n"+ "Your CTC is  "
            +notify.getInhandSalary()+",\n"+ "With Tax Deduction  " +notify.getTax());

            javaMailSender.send(msg);


    	
    	
	   return "Email sent successfully";   
	}
    
    
    
    
    
    
//    @PostMapping
//    public SimpleMailMessage sendFeedback(@RequestBody Feedback feedback){
//        
//
//        // Create a mail sender
//        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
//        mailSender.setHost(this.emailCfg.getHost());
//        mailSender.setPort(this.emailCfg.getPort());
//        mailSender.setUsername(this.emailCfg.getUsername());
//        mailSender.setPassword(this.emailCfg.getPassword());
//
//        // Create an email instance
//        SimpleMailMessage mailMessage = new SimpleMailMessage();
//        mailMessage.setFrom(feedback.getEmail());
//        mailMessage.setTo("gaikar.tejas22@gmail.com");
//        mailMessage.setSubject("New feedback from " + feedback.getName());
//        mailMessage.setText(feedback.getFeedback());
//
//       
//        // Send mail
//        mailSender.send(mailMessage);
//        return mailMessage;
//    }
}
