package com.tax.transparency.Security.Services;

import org.springframework.stereotype.Service;



@Service
public class TaxService {

	public double CalculateTax(long salary) {
		double temp=salary;
		
		if(temp>100000 && temp <300000)
		{
			
			temp=((temp-100000)*0.1);
		
		}
		else if(temp>300000)
		{
			temp=(((temp - 300000) *0.2) + (200000*0.1));
		}
		else
		{
			temp=0;
		}
		return temp;
	}
	
	
}
