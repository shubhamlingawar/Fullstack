package com.tax.transparency.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sun.istack.NotNull;


@Entity
@Table(name="tax")
public class Tax {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@NotNull
	@Column(name="payment_type")
	private String paymentType;
	
	@NotNull
	@Column(name="salary")
	private long salary;

	@NotNull
	@Column(name="actual_salary")
	private long actualSalary;
	
	@NotNull
	@Column(name="tax")
	private long tax;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "empid",referencedColumnName="id")
	@JsonIgnoreProperties("tax")
	private Employee employee;
	
	public Tax() {}
	
	public Tax(int id, String paymentType, long salary, long actualSalary, long tax, Employee employee) {
		this.id = id;
		this.paymentType = paymentType;
		this.salary = salary;
		this.actualSalary = actualSalary;
		this.tax = tax;
		this.employee = employee;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public long getActualSalary() {
		return actualSalary;
	}

	public void setActualSalary(long actualSalary) {
		this.actualSalary = actualSalary;
	}

	public long getTax() {
		return tax;
	}

	public void setTax(long tax) {
		this.tax = tax;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	

}
	